<?php
namespace Saleslayer\Synccatalog\Controller;

use Magento\Framework\App\ActionInterface;

interface SynccatalogInterface extends ActionInterface
{
}
