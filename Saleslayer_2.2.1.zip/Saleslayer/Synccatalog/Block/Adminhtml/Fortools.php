<?php
namespace Saleslayer\Synccatalog\Block\Adminhtml;

class Fortools extends \Magento\Framework\View\Element\Template
{

    
}
